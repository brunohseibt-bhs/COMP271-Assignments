package hand;

import cards.Card;

public class Hand {

    private Card[] cards; 

    public Hand(int handSize){

        cards = new Card[handSize];

    }

    public void addCard(Card dealtCard){

        for(int i = 0; i < cards.length; i++){
            if(cards[i] == null){
                cards[i] = dealtCard;
                break;
            }
        }
    }

    public void addCard(Card[] dealtCards){

        for(int i = 0; i < dealtCards.length; i++){
            addCard(dealtCards[i]);
        }

    }

    public void setCard(Card dealtCard, int index){

        cards[index] = dealtCard; //I'm placing the dealtCard inside my hand at a certain index

    }

    public Card getCard(int index){

        return cards[index];

    }

    public Card removeCard(int index){

        Card temp = cards[index]; //save the card
        cards[index] = null; // remove the card from deck (call it null)
        return temp;

    }

    public Card[] getCards(){

        return cards;

    }

    public String showAttributes(){

        String output = "Hand Faces: ";

        for(int i = 0; i < cards.length; i++){
            if(cards[i] != null){      //if I don't check for null Java will return NullPointerExecption if there is null at a certain index at cards[]
                output += cards[i].getFace() + " ";
            }
        }

        return output;

    }

    @Override
    public String toString(){

        String output = "";

        for(int i = 0; i < cards.length; i++){
            if(cards[i] != null){
                output += cards[i] + " ";
            }
        }

        return output;

    }
}
